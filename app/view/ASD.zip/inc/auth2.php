<?php
session_start();
if (isset($_SESSION["id"])) {
    header("Location: mapa.php");
    exit();
}

?>